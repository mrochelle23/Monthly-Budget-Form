//
//  main.cpp
//  Monthly Budget Form
//
//  Created by Mikhai Rochelle on 6/1/24.
//

#include <iostream>
#include <iomanip>
using namespace std;

struct MonthlyBudget {
    // Defined Variables
    double Housing;
    double Internet;
    double Household;
    double Transportation;
    double Food;
    double Medical;
    double Insurance;
    double Entertainment;
    double Clothing;
    double Miscellaneous;
};

void getTotalExpenses(MonthlyBudget &total) {
    cout << "Enter the total expenses for the month.\n";
    cout << "Housing: ";
    cin >> total.Housing;
    cout << "Utilities, Internet & Phone: ";
    cin >> total.Internet;
    cout << "Household Expenses: ";
    cin >> total.Household;
    cout << "Transportation: ";
    cin >> total.Transportation;
    cout << "Food: ";
    cin >> total.Food;
    cout << "Medical: ";
    cin >> total.Medical;
    cout << "Entertainment: ";
    cin >> total.Entertainment;
    cout << "Clothing: ";
    cin >> total.Clothing;
    cout << "Miscellaneous: ";
    cin >> total.Miscellaneous;
}


void displayBudgetComparison(const MonthlyBudget &budget, const MonthlyBudget &total) {
    double Budgeted = 0;
    double Total = 0;

    cout << fixed << setprecision(2);
    cout << "-------------------------------------------------------------------------------\n";
    cout << "Expenses               Budget                Total               Over/Under\n";
    cout << "-------------------------------------------------------------------------------\n";
    
    Budgeted += budget.Housing;
    Total += total.Housing;
    cout << "Housing            " << setw(10) << budget.Housing << setw(22) << total.Housing << setw(22) << "Under by " << budget.Housing - total.Housing << "\n";
    
    Budgeted += budget.Internet;
    Total += total.Internet;
    cout << "Internet            " << setw(10) << budget.Internet << setw(22) << total.Internet << setw(22) << "Under by " << budget.Internet - total.Internet << "\n";
    
    Budgeted += budget.Household;
    Total += total.Household;
    cout << "Household Expenses            " << setw(10) << budget.Household << setw(22) << total.Household << setw(22) << "Under by " << budget.Household - total.Household << "\n";
    
    Budgeted += budget.Transportation;
    Total += total.Transportation;
    cout << "Transportation            " << setw(10) << budget.Transportation << setw(22) << total.Transportation << setw(22) << "Under by " << budget.Transportation - total.Transportation << "\n";
    
    Budgeted += budget.Food;
    Total += total.Food;
    cout << "Food            " << setw(10) << budget.Food << setw(22) << total.Food << setw(22) << "Under by " << budget.Food - total.Food << "\n";
    
    Budgeted += budget.Medical;
    Total += total.Medical;
    cout << "Medical            " << setw(10) << budget.Medical << setw(22) << total.Medical << setw(22) << "Under by " << budget.Medical - total.Medical << "\n";
    
    Budgeted += budget.Insurance;
    Total += total.Insurance;
    cout << "Insurance            " << setw(10) << budget.Insurance << setw(22) << total.Insurance << setw(22) << "Under by " << budget.Insurance - total.Insurance << "\n";
    
    Budgeted += budget.Entertainment;
    Total += total.Entertainment;
    cout << "Entertainment            " << setw(10) << budget.Entertainment << setw(22) << total.Entertainment << setw(22) << "Under by " << budget.Entertainment - total.Entertainment << "\n";
    
    
    Budgeted += budget.Clothing;
    Total += total.Clothing;
    cout << "Clothing            " << setw(10) << budget.Clothing << setw(22) << total.Clothing << setw(22) << "Under by " << budget.Clothing - total.Clothing << "\n";
    
    Budgeted += budget.Miscellaneous;
    Total += total.Miscellaneous;
    cout << "Miscellaneous            " << setw(10) << budget.Miscellaneous << setw(22) << total.Miscellaneous << setw(22) << "Under by " << budget.Miscellaneous - total.Miscellaneous << "\n";
};

int main() {
    MonthlyBudget budget = {1000.00, 200.00, 63.00, 52.00, 250.00, 40.00, 125.00, 130.00, 80.00, 50.00};
    MonthlyBudget total;

    getTotalExpenses(total);
    displayBudgetComparison(budget, total);

    return 0;
}
